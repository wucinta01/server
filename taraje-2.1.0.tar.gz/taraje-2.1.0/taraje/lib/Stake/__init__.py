# -*- coding: utf-8 -*-
"""
    :Author: ampasmanusa (bancetzLaut) <0.ampasmanusa@gmail.com>
    :Created: 2022-07-02T20:45:29+07:00
    :Description: Stake.

    """
from typing import Final

_available_games: Final[set[str]] = {"Dice", "Limbo"}
