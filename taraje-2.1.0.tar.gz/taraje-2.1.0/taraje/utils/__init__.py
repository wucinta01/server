"""
    :Author: ampasmanusa (bancetzLaut) <0.ampasmanusa@gmail.com>
    :Created: 2023-01-16T11:25:05+07:00
    :Version: 0.1.0
    :Description: -

    """
