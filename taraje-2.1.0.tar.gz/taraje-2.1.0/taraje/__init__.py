"""
    :Author: ampasmanusa (bancetzLaut) <0.ampasmanusa@gmail.com>
    :Created: 2022-03-19T23:30:18+07:00
    :Version: 2.1.0
    :Description: Taraje's Bot.

    """
