.. raw:: html

    <h1 align="center">BL#378-Taraje</h1>

    <h3 align="center">rame-rame</h3>

    <p align="center">
        <code>
            <a href="https://t.me/ballataxart">
                bancetzLaut_
            </a>
            |
            <a href="https://t.me/bancetzLaut">
                ampasmanusa_
            </a>
        </code>
        <br>
        <a href="https://t.me/Taraje_dah">
            <code>#Tarajé__</code>
        </a>
    </p>
    <br>

